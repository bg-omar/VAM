% lines  a_x(j) b_x(j)  a_y(j)  b_y(j)  a_z(j)  b_z(j)
% corresponding to  x(s) = sum_ja_x(j)cos(js))+b_x(j)sin(js)  etc